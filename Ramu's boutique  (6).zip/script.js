let cart = [];

function addToCart(name, price){
  cart.push({name, price});
  updateCart();
}

function updateCart(){

  let items = document.getElementById("cart-items");
  let count = document.getElementById("cart-count");
  let total = 0;

  items.innerHTML = "";

  cart.forEach(item=>{
    total += item.price;
    items.innerHTML += `<p>${item.name} - $${item.price}</p>`;
  });

  count.innerText = cart.length;
  document.getElementById("cart-total").innerText = "Total: $" + total;
}

function openCart(){
  document.getElementById("cart-modal").style.display = "block";
}

function closeCart(){
  document.getElementById("cart-modal").style.display = "none";
}

function checkout(){

  let msg = "Hello, I want to order:%0A%0A";
  let total = 0;

  cart.forEach(item=>{
    msg += item.name + " - $" + item.price + "%0A";
    total += item.price;
  });

  msg += "%0ATotal: $" + total;

  window.open("https://wa.me/2207597080?text=" + msg);
}

/* SEARCH */
document.getElementById("searchInput").addEventListener("keyup", function(){

  let value = this.value.toLowerCase();
  let cards = document.querySelectorAll(".card");

  cards.forEach(card=>{
    let text = card.innerText.toLowerCase();
    card.style.display = text.includes(value) ? "block" : "none";
  });

});